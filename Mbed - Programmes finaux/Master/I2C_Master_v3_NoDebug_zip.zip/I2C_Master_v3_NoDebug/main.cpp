#include <mbed.h>

Serial pc(USBTX, USBRX); // Terminal PC
Serial bt(PA_9,PA_10); //Bluetooth
I2C i2c(PB_7,PB_6);   // SDA, SCL

void scan_I2CSlave();

int i = 0;
int  ack = 1;//ACK
const int  addr = 0xA0;// Adresse du Slave

char MasterRX[15] = {0}; //Réception Master
char MasterTX[7][15] = { //Emission Master
    "Longitude",
    "Latitude",
    "Altitude",
    "Humidite",
    "Temperature",
    "Son",
    "Lumiere"
};

int main()
{
    bt.baud(115200);//Vitesse de transmission
    
    i2c.frequency(100000); //Horloge
    
    //Chercher s'il y a un Slave
    scan_I2CSlave();

    i = 0;
    while(1) {

        i2c.write(addr,MasterTX[i],15,1); //Envoi d'un "mots"

        i2c.read(addr,MasterRX,15); //Réception de la valeur du capteur selon le mots qu'on a envoyé
        pc.printf("%s : %s\n\r",MasterTX[i],MasterRX);
        
        //Envoi en bluetooth des différentes valeurs
        int len = strlen(MasterTX[i]);//Vérification de la longueur du mots que l'on a envoyé
        
        //Comparaison avec ce que l'on a envoyé et avec le tableau contenant tous les "mots"
        //En cas de correspondance, envoi en bluettoth de la valeur du capteur selon le "mots"
        if(strncmp(MasterTX[i], MasterTX[0], len)==0)bt.printf("c%s",MasterRX);
        else if(strncmp(MasterTX[i], MasterTX[1], len)==0)bt.printf("b%s",MasterRX);
        else if(strncmp(MasterTX[i], MasterTX[2], len)==0)bt.printf("a%s",MasterRX);
        else if(strncmp(MasterTX[i], MasterTX[3], len)==0)bt.printf("h%s",MasterRX);
        else if(strncmp(MasterTX[i], MasterTX[4], len)==0)bt.printf("t%s",MasterRX);
        else if(strncmp(MasterTX[i], MasterTX[5], len)==0)bt.printf("s%s",MasterRX);
        else if(strncmp(MasterTX[i], MasterTX[6], len)==0)bt.printf("l%s",MasterRX);
        
        i++;
        if (i == 7)i=0;
        
    }
}

void scan_I2CSlave()
{
    int  search = 0;

    // Debug
    pc.printf("\fmbed I2C debug tool ready\n\r");

    // Scan I2C Slave
    for (i=0; i<=254; i=i+2) {
        if (i2c.read(i, &MasterRX[0], 15) == 0) {
            pc.printf("I2C device detected at address = 0x%02X\n\r", i);
            search++;
            break;
        }
    }
    if (search == 0) {
        pc.printf("I2C Slaves NO DETECTED!\n\r");
    } else {
        pc.printf("I2C Slaves %d\n\r",search);
    }
}