#include <mbed.h>

Serial pc(USBTX, USBRX); // tx, rx
I2C i2c(PB_7,PB_6);   // SDA, SCL

int i;
int  ack = 1;
const int  addr = 0xA0;
char MasterTX[] = "Master";
char MasterRX[5] = {0};


int main()
{
    int  search = 0;
    i2c.frequency(100000); //Set the clock frequency

    // Debug
    pc.printf("\fmbed I2C debug tool ready\n\r");

    // Scan I2C Slave
    for (i=0; i<=254; i=i+2) {
        if (i2c.read(i, &MasterRX[0], 1) == 0) {
            pc.printf("I2C device detected at address = 0x%02X\n\r", i);
            search++;
        }
    }
    if (search == 0) {
        pc.printf("I2C Slaves NO DETECTED!\n\r");
    } else {
        pc.printf("I2C Slaves %d\n\r",search);
    }


    while(1) {
        //Write
        ack = i2c.write(addr,MasterTX,6,1);
        if (ack == 0) {     // SAK Slave ACK
            pc.printf("ACK Write\n\r");
        } else {          // NSAK Non Slave ACK
            pc.printf("NACK Write\n\r");
        }
        
        
        //Read
        ack = i2c.read(addr,MasterRX,5sizeof(MasterRX));
        if (ack == 0) {     // SAK Slave ACK
            pc.printf("ACK Read\n\r");
        } else {         // NSAK Non Slave ACK
            pc.printf("NACK Read\n\r");
        }
        
    }
}