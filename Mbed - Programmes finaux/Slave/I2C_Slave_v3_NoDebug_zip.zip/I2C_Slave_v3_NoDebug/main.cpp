#include "mbed.h"
#include "GPS.h"
#include "DHT.h"

Serial pc(USBTX, USBRX);//Terminal
GPS _gps(PA_9, PA_10);//GPS

I2CSlave slave(PB_7, PB_6);// SDA, SCL

AnalogIn pin_son(A2); //Capteur son 
AnalogIn pin_lum(A1); //Capteur lumière
DHT sensor(A0,SEN11301P); //Capteur humidité & temperature

char SlaveTX[256] = {}; //Emission Slave
char SlaveRX[15];       //Réception Slave

enum {
    LONGITUDE = 0,
    LATITUDE = 1,
    ALTITUDE = 2,
    HUMIDITE = 3,
    TEMPERATURE = 4,
    SON = 5,
    LUMIERE = 6,
    MAXVALUE=7
};

//Tableau contenant tous les mots que l'on receverra du Master
char lookupTable[7][15] = {
    "Longitude",
    "Latitude",
    "Altitude",
    "Humidite",
    "Temperature",
    "Son",
    "Lumiere"
};
//Initialisation des variables
int erreur, temp = 0;;
float valeur_son,valeur_lum,v_luminance;
float Longitude = 0.0, Latitude = 0.0, Altitude = 0.0, Humidite = 0.0, Temperature = 0.0, Son = 0.0, Lumiere = 0.0;

int main()
{
    slave.address(0xA0);

    while(1) {
        // ------------------------ partie capteur GPS--------------------------
        temp = 1;
        //Lecture de la longitude, latitude et de l'altitude
        temp = _gps.sample(&Longitude,&Latitude,&Altitude); 
        
        // ----------------- partie capteur de tempertature & humidité----------
        erreur = sensor.readData();
        if (erreur == 0) {
            Temperature =  sensor.ReadTemperature(CELCIUS); //Lecture du température 
            Humidite =  sensor.ReadHumidity();  //Lecture de l'humitidté
        } 
        else{
            //En cas d'erreur
            pc.printf("\r\nErr %i \n\r",erreur);
            wait(0.5);
        }
        
        //--------------------partie capteur de son ----------------------------
        valeur_son=pin_son.read();
        Son = valeur_son;
        
        // ----------------- partie capteur de lumière--------------------------
        valeur_lum=pin_lum.read();
        v_luminance = valeur_lum*1000.0;
        Lumiere = v_luminance;
        
        // ---------------------------------------------------------------------
        
        // --------------------- partie I2C Slave-------------------------------
        int i = slave.receive();
        switch (i) {
            case I2CSlave::ReadAddressed:   //Envoi
                slave.write(SlaveTX, 15);
                break;
            case I2CSlave::WriteAddressed:  //Reception
                slave.read(SlaveRX, 15);
                //pc.printf("Read A: %s\n\r", SlaveRX);
                break;
        }
        
        //Comparaison entre le "mots" de la reception et un tableau contenant tout les mots
        int rec;
        for(rec=0; rec < MAXVALUE; rec++) {
            int len = strlen(lookupTable[rec]); //Longueur du "mots" dans le tableau lookupTable
            int ret = strncmp(SlaveRX, lookupTable[rec], len); //Comparaison entre SlaveRX et lookupTable
            if(ret == 0)break; //En cas de correspondance, sortir de la boucle
        }

        //Conversion float to char[]
        //De la valeur reçu par le capteur selon le "mots" reçu
        switch(rec) {
            case LONGITUDE:
                sprintf(SlaveTX,"%.4f",Longitude);
                break;
            case LATITUDE:
                sprintf(SlaveTX,"%.4f",Latitude);
                break;
            case ALTITUDE:
                sprintf(SlaveTX,"%.4f",Altitude);
                break;
            case HUMIDITE:
                sprintf(SlaveTX,"%.2f",Humidite);
                break;
            case TEMPERATURE:
                sprintf(SlaveTX,"%.2f",Temperature);
                break;
            case SON:
                sprintf(SlaveTX,"%.2f",Son);
                break;
            case LUMIERE:
                sprintf(SlaveTX,"%.2f",Lumiere);
                break;
            default:
                break;
        }
        // ---------------------------------------------------------------------;

    }
}