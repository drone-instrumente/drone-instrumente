#include "mbed.h"
#include "GPS.h"

Serial pc(USBTX, USBRX);
GPS _gps(PA_9, PA_10);

I2CSlave slave(PB_7, PB_6);

char SlaveTX[256] = {};
char SlaveRX[15];

enum {
    LONGITUDE = 0,
    LATITUDE = 1,
    ALTITUDE = 2,
    HUMIDITE = 3,
    TEMPERATURE = 4,
    SON = 5,
    LUMIERE = 6,
    MAXVALUE=7
};

char lookupTable[7][15] = {
    "Longitude",
    "Latitude",
    "Altitude",
    "Humidite",
    "Temperature",
    "Son",
    "Lumiere"
};

int main()
{
    int temp = 0;
    float Longitude = 0.0, Latitude = 0.0, Altitude = 0.0, Humidite = 0.0, Temperature = 0.0, Son = 0.0, Lumiere = 0.0;

    slave.address(0xA0);

    while(1) {

        temp = 1;
        //temp = _gps.sample(&Longitude,&Latitude,&Altitude);
        
        Longitude = 1.0, Latitude = 2.0, Altitude = 3.0, Humidite = 4.0, Temperature = 5.0, Son = 6.0, Lumiere = 7.0;

        int i = slave.receive();
        switch (i) {
            case I2CSlave::ReadAddressed:
                slave.write(SlaveTX, 15);
                pc.printf("Test : %s\n\r",SlaveTX);
                break;
            case I2CSlave::WriteGeneral:
                slave.read(SlaveRX, 15);
                pc.printf("Read G: %s\n", SlaveRX);
                break;
            case I2CSlave::WriteAddressed:
                slave.read(SlaveRX, 15);
                pc.printf("Read A: %s\n\r", SlaveRX);
                break;
        }

        int rec;
        for(rec=0; rec < MAXVALUE; rec++) {
            int len = strlen(lookupTable[rec]);
            int ret = strncmp(SlaveRX, lookupTable[rec], len);
            if(ret == 0) 
            {
                pc.printf("Correspondance ok\n\r");
                break;
            }
            else pc.printf("return value is %d in '%s' and '%s' comparison\n\r", ret, SlaveRX, lookupTable[rec]);
        }

        pc.printf("\n");

        switch(rec) {
            case LONGITUDE:
                sprintf(SlaveTX,"%f",Longitude);
                break;
            case LATITUDE:
                sprintf(SlaveTX,"%f",Latitude);
                break;
            case ALTITUDE:
                sprintf(SlaveTX,"%f",Altitude);
                break;
            case HUMIDITE:
                sprintf(SlaveTX,"%f",Humidite);
                break;
            case TEMPERATURE:
                sprintf(SlaveTX,"%f",Temperature);
                break;
            case SON:
                sprintf(SlaveTX,"%f",Son);
                break;
            case LUMIERE:
                sprintf(SlaveTX,"%f",Lumiere);
                break;
            default:
                break;
        }

    }
}