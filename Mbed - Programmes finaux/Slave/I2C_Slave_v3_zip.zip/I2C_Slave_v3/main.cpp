#include "mbed.h"
#include "GPS.h"
#include "DHT.h"

Serial pc(USBTX, USBRX);//Terminal
GPS _gps(PA_9, PA_10);

I2CSlave slave(PB_7, PB_6);

AnalogIn pin_son(A2); //pin capteur son 
AnalogIn pin_lum(A1); // pin capteur lumière
DHT sensor(A0,SEN11301P); // capteur humidité & temperature

char SlaveTX[256] = {};
char SlaveRX[15];

enum {
    LONGITUDE = 0,
    LATITUDE = 1,
    ALTITUDE = 2,
    HUMIDITE = 3,
    TEMPERATURE = 4,
    SON = 5,
    LUMIERE = 6,
    MAXVALUE=7
};

char lookupTable[7][15] = {
    "Longitude",
    "Latitude",
    "Altitude",
    "Humidite",
    "Temperature",
    "Son",
    "Lumiere"
};

float valeur_son,valeur_lum, v_pourcentage,v_luminance;
int erreur ;
float temperature, humidity,son;

int main()
{
    int temp = 0;
    
    float Longitude = 0.0, Latitude = 0.0, Altitude = 0.0, Humidite = 0.0, Temperature = 0.0, Son = 0.0, Lumiere = 0.0;

    slave.address(0xA0);
    //slave.frequency(400000);
    
    //Longitude = 220.0445, Latitude = 4847.6725 //Coordonnées Cachan

    while(1) {

        // ------------------------ partie capteur GPS--------------------------
        temp = 1;
        temp = _gps.sample(&Longitude,&Latitude,&Altitude);
        
        // ----------------- partie capteur de tempertature & humidité----------
        erreur = sensor.readData();
        if (erreur == 0) {
            Temperature =  sensor.ReadTemperature(CELCIUS);
            Humidite =  sensor.ReadHumidity();      
            //pc.printf("Temperature %4.2f ",temperature);
            //pc.printf("Humidite %4.2f %% \n\r",humidity);
             
        } 
        else{
            pc.printf("\r\nErr %i \n\r",erreur);
            wait(0.5);
        }
        
        //--------------------partie capteur de son ----------------------------
        
        valeur_son=pin_son.read();
        Son = valeur_son;
        
        // ----------------- partie capteur de lumière--------------------------
        valeur_lum=pin_lum.read();
        v_luminance = valeur_lum*1000.0;
        Lumiere = v_luminance;
        
        // ---------------------------------------------------------------------
        /*Longitude = 1.0, Latitude = 2.0, Altitude = 3.0, Humidite = 4.0, Temperature = 5.0, Son = 6.0, Lumiere = 7.0;*/
        
        // ---------------------------------------------------------------------
        
        // --------------------- partie I2C Slave-------------------------------
        int i = slave.receive();
        switch (i) {
            case I2CSlave::ReadAddressed:   //Envoi
                slave.write(SlaveTX, 15);
                pc.printf("Test : %s\n\r",SlaveTX);
                break;
            case I2CSlave::WriteGeneral:
                slave.read(SlaveRX, 15);
                pc.printf("Read G: %s\n", SlaveRX);
                break;
            case I2CSlave::WriteAddressed:  //Reception
                slave.read(SlaveRX, 15);
                pc.printf("Read A: %s\n\r", SlaveRX);
                break;
        }
        
        //Comparaison entre la réception et les IDs
        int rec;
        for(rec=0; rec < MAXVALUE; rec++) {
            int len = strlen(lookupTable[rec]);
            int ret = strncmp(SlaveRX, lookupTable[rec], len);
            if(ret == 0) {
                pc.printf("Correspondance ok\n\r");
                break;
            } else pc.printf("return value is %d in '%s' and '%s' comparison\n\r", ret, SlaveRX, lookupTable[rec]);
        }

        pc.printf("\n");

        //Conversion float to char[]
        switch(rec) {
            case LONGITUDE:
                sprintf(SlaveTX,"%f",Longitude);
                break;
            case LATITUDE:
                sprintf(SlaveTX,"%f",Latitude);
                break;
            case ALTITUDE:
                sprintf(SlaveTX,"%f",Altitude);
                break;
            case HUMIDITE:
                sprintf(SlaveTX,"%f",Humidite);
                break;
            case TEMPERATURE:
                sprintf(SlaveTX,"%f",Temperature);
                break;
            case SON:
                sprintf(SlaveTX,"%f",Son);
                break;
            case LUMIERE:
                sprintf(SlaveTX,"%f",Lumiere);
                break;
            default:
                break;
        }
        // ---------------------------------------------------------------------;

    }
}