#include "mbed.h"
#include "GPS.h"

Serial pc(USBTX, USBRX);

I2CSlave slave(PB_7, PB_6);

char SlaveTX[] = "Slave";
char SlaveRX[10];

int main()
{

    slave.address(0xA0);

    while(1) {

        int i = slave.receive();
        switch (i) {
            case I2CSlave::ReadAddressed:
                slave.write(SlaveTX, 10);
                break;
            case I2CSlave::WriteGeneral:
                slave.read(SlaveRX, 10);
                pc.printf("Read G: %s\n", SlaveRX);
                break;
            case I2CSlave::WriteAddressed:
                slave.read(SlaveRX, 10);
                pc.printf("Read A: %s\n", SlaveRX);
                break;
        }

        for(int i = 0; i < 9; i++) SlaveRX[i] = 0;    // Clear buffer


    }
}