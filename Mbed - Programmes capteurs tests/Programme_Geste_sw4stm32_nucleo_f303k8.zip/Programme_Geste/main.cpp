#include "mbed.h"
#include "PAJ7620U2.h"

Serial pc(USBTX, USBRX);
PAJ7620U2 i2c(D4,D5);
Serial bt(PA_9,PA_10); 
int main()
{
    bt.baud(115200);
    char data_read[2];
    char valeur =0;
    int mode =0;
    pc.printf("-------------INITIALISATION DU CAPTEUR-------------- \n\r");
    while(1) {
        i2c.RegRead(0x43, data_read, 1);
        valeur= data_read[0];
        switch (valeur) {
            case 1:
                bt.printf("%dg", valeur);
                pc.printf("AVANCER \n\r");
                break;
            case 2:
                bt.printf("%dg", valeur);
                pc.printf("RECULER \n\r");
                break;
            case 4:
                bt.printf("%dg", valeur);
                pc.printf("ALLER A GAUCHE \n\r");
                break;
            case 8:
                bt.printf("%dg", valeur);
                pc.printf("ALLER A DROITE \n\r");
                break;
            case 16:
                bt.printf("%dg", valeur);
                pc.printf("DESCENDRE \n\r");
                break;
            case 32:
                for (int i=0; i<=1; i++){
                    bt.printf("%dg", valeur);
                    wait(0.3);
                }
                pc.printf("MONTER \n\r");
                
                break;
            case 64:
                for (int i=0; i<=3; i++){
                    bt.printf("%dg", valeur);
                    pc.printf("ROTATION \n\r");
                    wait(0.3);
                 }   
                break;
            case 128:
                for (int i=0; i<=3; i++){
                    bt.printf("%dg", valeur);
                    pc.printf("ROTATION INVERSE \n\r");
                    wait(0.3);
                }
                break;
        }
        wait(0.3);
    }
}