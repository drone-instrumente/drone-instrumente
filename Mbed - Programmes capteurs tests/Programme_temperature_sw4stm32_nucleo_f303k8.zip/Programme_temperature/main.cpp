#include "mbed.h"
#include "DHT.h"


Serial pc(USBTX, USBRX); // tx, rx
AnalogIn pin_SS(A0);
DHT sensor(A0,SEN11301P);

int erreur ;
int main(){
    
    while(1){
      erreur = sensor.readData();
      if (erreur == 0) {
          
        pc.printf( "Temperature %4.2f ",sensor.ReadTemperature(CELCIUS));
        pc.printf( "Humidite %4.2f %%",sensor.ReadHumidity());
        pc.printf(" \n\r");
        wait(1);
      } else
            printf("\r\nErr %i \n",erreur);
        wait(0.5);
     }  
}
 