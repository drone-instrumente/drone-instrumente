#include "mbed.h"
#include "GPS.h"

Serial pc(USBTX, USBRX);
GPS _gps(PA_9, PA_10);


int main() {
    
    int temp = 0;
    float Longitude = 0.0, Latitude = 0.0, Altitude = 0.0;
    
    while(1) {
        
        temp = 1;
        temp = _gps.sample(&Longitude,&Latitude,&Altitude);
        
        pc.printf("\n\rlongitude est %f\n\r", Longitude);
        pc.printf("\n\rlatitude est %f\n\r", Latitude);
        pc.printf("altitude is %f\n\r", Altitude);
        
    }
}