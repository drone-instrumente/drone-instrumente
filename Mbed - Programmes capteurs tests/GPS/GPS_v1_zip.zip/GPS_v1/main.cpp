#include "mbed.h"
#include "GPS.h"

GPS _gps(PA_9, PA_10);


int main() {
    
    int temp = 0;
    
    while(1) {
        
        temp = 1;
        temp = _gps.sample();
        
    }
}