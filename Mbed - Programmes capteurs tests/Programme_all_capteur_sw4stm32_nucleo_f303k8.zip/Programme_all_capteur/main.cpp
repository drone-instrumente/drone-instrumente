#include "mbed.h"
#include "DHT.h"
Serial pc(USBTX, USBRX); // tx, rx
Serial bt(PB_6,PB_7);
DigitalOut myled(LED1);
AnalogIn pin_son(A2); //pin capteur son 
AnalogIn pin_lum(A1); // pin capteur lumière
DHT sensor(A0,SEN11301P); // capteur humidité & temperature

float valeur_son,valeur_lum, v_pourcentage,v_luminance;
int erreur ;
float temperature, humidity,son,lumiere;


int main() {
    pc.baud(115200);
    bt.baud(115200);
    while(1) {
       valeur_son=pin_son.read();
       valeur_lum=pin_lum.read();
       //--------------------partie capteur de son -----------------------------
        
        pc.printf( "%.2f\n\r", valeur_son);
        
        
        // ----------------- partie capteur de lumière--------------------------
        
        v_luminance = valeur_lum*1000;
        lumiere = v_luminance;
        pc.printf( "la luminance est de   :  %.2f lx \n\r",lumiere);    
        
        
        // ----------------- partie capteur de tempertature & humidité----------
        erreur = sensor.readData();
        if (erreur == 0) {
            temperature =  sensor.ReadTemperature(CELCIUS);
            humidity =  sensor.ReadHumidity();      
            pc.printf( "Temperature %4.2f ",temperature);
            pc.printf( "Humidite %4.2f %% \n\r",humidity);
            
            
            
        } else{
            printf("\r\nErr %i \n\r",erreur);
            wait(0.5);
            }
        bt.printf("s %4.2f",son);
        wait(0.2);
        bt.printf("l %4.2f",lumiere);
        wait(0.2);
        bt.printf("t %4.2f",temperature);
        wait(0.2);
        bt.printf("h %4.2f",humidity);
        wait(0.2);
        }  
    }

