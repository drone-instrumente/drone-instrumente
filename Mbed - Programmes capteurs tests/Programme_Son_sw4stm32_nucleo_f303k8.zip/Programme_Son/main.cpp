#include "mbed.h"

Serial pc(USBTX, USBRX, 9600); // tx, rx
AnalogIn pin_SS(A2);
int valeur;
float calcule;

int main(){
    
    while(1){
        
        valeur=pin_SS.read();
        pc.printf("%.2f \n\r",valeur);
        wait (0.2);
        
      
     }  
}

