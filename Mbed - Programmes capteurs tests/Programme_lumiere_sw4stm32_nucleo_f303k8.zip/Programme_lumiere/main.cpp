#include "mbed.h"

Serial pc(USBTX, USBRX); // tx, rx

//const int pin_SS=A0;
AnalogIn pin_SS(A1);
float valeur,v_luminance;

int main(){
    while(1){
      valeur=pin_SS.read();
      v_luminance= valeur*1000;
      pc.printf( "la luminance est de   :  %.2f",v_luminance);
      pc.printf(" lx \n\r");     
      wait (0.5);
      
      
     }  
}