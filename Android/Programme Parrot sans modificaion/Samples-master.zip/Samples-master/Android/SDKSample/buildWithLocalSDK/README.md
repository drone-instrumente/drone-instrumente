#Build with local SDK

You can build this sample with the localy compiled ARSDK libraries using this build.gradle.

Simply type `./gradlew assembleDebug` to build the sample with your own libraries (located in ../../../../../out/...).