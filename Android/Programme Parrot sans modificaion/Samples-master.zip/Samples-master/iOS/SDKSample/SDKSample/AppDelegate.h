//
//  AppDelegate.h
//  SDKSample
//
//  Created by Djavan Bertrand on 24/02/2016.
//  Copyright © 2016 Parrot. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

