//
//  SkyController2VC.h
//  SDKSample
//

#import <UIKit/UIKit.h>
#import <libARDiscovery/ARDISCOVERY_BonjourDiscovery.h>

@interface SkyController2VC : UIViewController

@property (nonatomic, strong) ARService *service;

@end
