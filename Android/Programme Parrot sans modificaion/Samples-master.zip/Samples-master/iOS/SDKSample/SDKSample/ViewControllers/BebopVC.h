//
//  BebopVC.h
//  SDKSample
//

#import <UIKit/UIKit.h>
#import <libARDiscovery/ARDISCOVERY_BonjourDiscovery.h>

@interface BebopVC : UIViewController

@property (nonatomic, strong) ARService *service;

@end
